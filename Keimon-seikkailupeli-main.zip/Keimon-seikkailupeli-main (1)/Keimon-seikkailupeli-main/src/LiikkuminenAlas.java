public class LiikkuminenAlas extends Liikkuminen{
    
}
