public class LiikkuminenOikealle extends Liikkuminen{
    
}
