public class LiikkuminenYlös extends Liikkuminen{
    
}
