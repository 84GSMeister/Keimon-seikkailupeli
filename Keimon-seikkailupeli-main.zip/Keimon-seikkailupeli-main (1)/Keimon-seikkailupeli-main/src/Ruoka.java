public class Ruoka extends Esine{
    int heal;

    int annaParannusMäärä() {
        return heal;
    }
    
    Ruoka() {

    }
}
