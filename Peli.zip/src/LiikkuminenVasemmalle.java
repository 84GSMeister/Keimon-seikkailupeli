public class LiikkuminenVasemmalle extends Liikkuminen{
    
}
