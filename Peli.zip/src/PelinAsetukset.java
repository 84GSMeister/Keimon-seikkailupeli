public class PelinAsetukset {
    
    static int vaikeusAste = 1;
    static boolean musiikkiPäällä = false;
    static int musiikkiValinta = 0;
}
